/**
 * Re-export useAuth hook from auth context for convenience
 */
export { useAuth } from '@/contexts/auth-context';
